<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\BallTask;


class BallController extends Controller
{
    //
    public function index_c()
    {
   return view ('index');
    }

    /****************************** */

    public function store(Request $request) {      
        $pink = $request->input('pink');
        $red =  $request->input('red');
         $cc = 0.0;
         $calred = $red;
        $blue = $request->input('blue');
        $calblue = $blue.''.$cc;
        $orange =  $request->input('orange');
        $green =  $request->input('green');
        $calculated = $pink + $red + $blue + $orange +$green;
         $bucketA = 20;       
         $buck =   $bucketA - $calculated;
        $tt = str_replace('-', '', $buck);       
       $tot =  $tt.''.'Extra Ball';      
      return redirect()->back()->withInput()->with('statusA', $tot);

    }

    public function storeB(Request $request) {      
        $pink = $request->input('pink');
        $red =  $request->input('red');
         $cc = 0.0;
         $calred = $red;
        $blue = $request->input('blue');
        $calblue = $blue.''.$cc;
        $orange =  $request->input('orange');
        $green =  $request->input('green');
        $calculated = $pink + $red + $blue + $orange +$green;
         $bucketA = 18;       
         $buck =   $bucketA - $calculated;
        $tt = str_replace('-', '', $buck);       
       $totB =  $tt.''.'Extra Ball';      
      return redirect()->back()->withInput()->with('statusB', $totB);

    }



    public function storeC(Request $request) {      
        $pink = $request->input('pink');
        $red =  $request->input('red');
         $cc = 0.0;
         $calred = $red;
        $blue = $request->input('blue');
        $calblue = $blue.''.$cc;
        $orange =  $request->input('orange');
        $green =  $request->input('green');
        $calculated = $pink + $red + $blue + $orange +$green;
         $bucketA = 12;       
         $buck =   $bucketA - $calculated;
        $tt = str_replace('-', '', $buck);       
       $totC =  $tt.''.'Extra Ball';      
      return redirect()->back()->withInput()->with('statusC', $totC);

    }



    public function storeD(Request $request) {      
        $pink = $request->input('pink');
        $red =  $request->input('red');
         $cc = 0.0;
         $calred = $red;
        $blue = $request->input('blue');
        $calblue = $blue.''.$cc;
        $orange =  $request->input('orange');
        $green =  $request->input('green');
        $calculated = $pink + $red + $blue + $orange +$green;
         $bucketA = 10;       
         $buck =   $bucketA - $calculated;
        $tt = str_replace('-', '', $buck);       
       $totD =  $tt.''.'Extra Ball';      
      return redirect()->back()->withInput()->with('statusD', $totD);

    }


    public function storeE(Request $request) {      
        $pink = $request->input('pink');
        $red =  $request->input('red');
         $cc = 0.0;
         $calred = $red;
        $blue = $request->input('blue');
        $calblue = $blue.''.$cc;
        $orange =  $request->input('orange');
        $green =  $request->input('green');
        $calculated = $pink + $red + $blue + $orange +$green;
         $bucketA = 8;       
         $buck =   $bucketA - $calculated;
        $tt = str_replace('-', '', $buck);       
       $totalE =  $tt.''.'Extra Ball';      
      return redirect()->back()->withInput()->with('statusE', $totalE);

    }
}
