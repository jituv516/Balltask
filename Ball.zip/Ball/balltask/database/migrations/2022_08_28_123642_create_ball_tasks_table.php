<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBallTasksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ball_tasks', function (Blueprint $table) {
            $table->id();
            $table->string('pink')->nullable();
            $table->string('red')->nullable();
            $table->string('blue')->nullable();
            $table->string('orange')->nullable();
            $table->string('green')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ball_tasks');
    }
}
