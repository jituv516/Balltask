<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BallController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('index', [BallController::class, 'index_c']);
Route::post('bucketA', [BallController::class, 'store']);
Route::post('bucketB', [BallController::class, 'storeB']);
Route::post('bucketC', [BallController::class, 'storeC']);
Route::post('bucketD', [BallController::class, 'storeD']);
Route::post('bucketE', [BallController::class, 'storeE']);

