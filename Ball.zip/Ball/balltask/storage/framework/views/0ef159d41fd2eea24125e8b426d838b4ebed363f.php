<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bucket</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Bucket Task (Pink: 2.5, Red: 2 , Blue : 1 , Orange : 0.8 ,green :0.5)</h2>
  <hr/>
  <?php if(session('statusA')): ?>
  <h6 class="alert alert-success"><?php echo e(session('statusA')); ?></h6>
<?php endif; ?>
 <div class="row">
    <p> Bucket A </p>
    <form method="POST" action="<?php echo e(url('bucketA')); ?>">
       <?php echo csrf_field(); ?>
  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Pink:</label>
        <input type="text" class="form-control"  name="pink" placeholder="Pink Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Red:</label>
        <input type="text" class="form-control"name="red" placeholder="Red Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Blue:</label>
        <input type="text" class="form-control" name="blue" placeholder="Blue Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Orange:</label>
        <input type="text" class="form-control" name="orange" placeholder="Orange Ball">
      </div>
  </div>


  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Green:</label>
        <input type="text" class="form-control" name="green" placeholder="Green Ball">
      </div>
  </div>

  <div class="col-md-2">
    <input type="submit" class="btn btn-primary" name="submit" value="Submit"> 

  </div>
</form>
 </div>
</div>
<hr/>

<!-------============= Bucket B ========================----->
<div class="container">
  <h4>Bucket </h4>
  <?php if(session('statusB')): ?>
  <h6 class="alert alert-success"><?php echo e(session('statusB')); ?></h6>
<?php endif; ?>
 <div class="row">
    <p> Bucket A </p>
    <form method="POST" action="<?php echo e(url('bucketB')); ?>">
       <?php echo csrf_field(); ?>
  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Pink:</label>
        <input type="text" class="form-control"  name="pink" placeholder="Pink Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Red:</label>
        <input type="text" class="form-control"name="redB" placeholder="Red Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Blue:</label>
        <input type="text" class="form-control" name="blueB" placeholder="Blue Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Orange:</label>
        <input type="text" class="form-control" name="orangeB" placeholder="Orange Ball">
      </div>
  </div>


  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Green:</label>
        <input type="text" class="form-control" name="greenB" placeholder="Green Ball">
      </div>
  </div>

  <div class="col-md-2">
    <input type="submit" class="btn btn-primary" name="submitB" value="Submit"> 

  </div>
</form>
 </div>
</div>

<hr/>
<!--------=========== Bucket C ========================------>

<div class="container">
  <h4>Bucket </h4>
  <?php if(session('statusC')): ?>
  <h6 class="alert alert-success"><?php echo e(session('statusC')); ?></h6>
<?php endif; ?>
 <div class="row">
    <p> Bucket A </p>
    <form method="POST" action="<?php echo e(url('bucketC')); ?>">
       <?php echo csrf_field(); ?>
  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Pink:</label>
        <input type="text" class="form-control"  name="pinkC" placeholder="Pink Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Red:</label>
        <input type="text" class="form-control"name="redC" placeholder="Red Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Blue:</label>
        <input type="text" class="form-control" name="blueC" placeholder="Blue Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Orange:</label>
        <input type="text" class="form-control" name="orangeC" placeholder="Orange Ball">
      </div>
  </div>


  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Green:</label>
        <input type="text" class="form-control" name="greenC" placeholder="Green Ball">
      </div>
  </div>

  <div class="col-md-2">
    <input type="submit" class="btn btn-primary" name="submitC" value="Submit"> 

  </div>
</form>
 </div>
</div>
<!----------============== Bucket D =====================---------->
<hr/>
<div class="container">
  <h4>Bucket </h4>
  <?php if(session('statusD')): ?>
  <h6 class="alert alert-success"><?php echo e(session('statusD')); ?></h6>
<?php endif; ?>
 <div class="row">
    <p> Bucket D </p>
    <form method="POST" action="<?php echo e(url('bucketD')); ?>">
       <?php echo csrf_field(); ?>
  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Pink:</label>
        <input type="text" class="form-control"  name="pinkD" placeholder="Pink Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Red:</label>
        <input type="text" class="form-control"name="redD" placeholder="Red Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Blue:</label>
        <input type="text" class="form-control" name="blueD" placeholder="Blue Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Orange:</label>
        <input type="text" class="form-control" name="orangeD" placeholder="Orange Ball">
      </div>
  </div>


  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Green:</label>
        <input type="text" class="form-control" name="greenD" placeholder="Green Ball">
      </div>
  </div>

  <div class="col-md-2">
    <input type="submit" class="btn btn-primary" name="submitD" value="Submit"> 

  </div>
</form>
 </div>
</div>
<hr/>
<!------=================== Bucket E =====================================---------->
<div class="container">
  <h4>Bucket </h4>
  <?php if(session('statusE')): ?>
  <h6 class="alert alert-success"><?php echo e(session('statusE')); ?></h6>
<?php endif; ?>
 <div class="row">
    <p> Bucket E </p>
    <form method="POST" action="<?php echo e(url('bucketE')); ?>">
       <?php echo csrf_field(); ?>
  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Pink:</label>
        <input type="text" class="form-control"  name="pinkE" placeholder="Pink Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Red:</label>
        <input type="text" class="form-control"name="redE" placeholder="Red Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Blue:</label>
        <input type="text" class="form-control" name="blueE" placeholder="Blue Ball">
      </div>
  </div>

  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Orange:</label>
        <input type="text" class="form-control" name="orangeE" placeholder="Orange Ball">
      </div>
  </div>


  <div class="col-md-2">
    <div class="form-group">
        <label for="usr">Green:</label>
        <input type="text" class="form-control" name="greenE" placeholder="Green Ball">
      </div>
  </div>

  <div class="col-md-2">
    <input type="submit" class="btn btn-primary" name="submitE" value="Submit"> 

  </div>
</form>
 </div>
</div>

<!------============================================--------->

</body>
</html>
<?php /**PATH D:\Ball\balltask\resources\views/index.blade.php ENDPATH**/ ?>